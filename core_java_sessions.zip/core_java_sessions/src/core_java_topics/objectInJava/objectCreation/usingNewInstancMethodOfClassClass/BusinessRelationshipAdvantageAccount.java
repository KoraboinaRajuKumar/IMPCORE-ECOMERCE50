package core_java_topics.objectInJava.objectCreation.usingNewInstancMethodOfClassClass;

public class BusinessRelationshipAdvantageAccount {

	//declare instance variable
	//syntax to declare instance variable
	//access_specifier data_type variable_name
	
	private long baa_acc_number;
	private String baa_customer_name;
	private String baa_branch_name;
	private String baa_city;
	private long pin_code;
	private double baa_acc_balance;
	
	public long getBaa_acc_number() {
		return baa_acc_number;
	}
	public void setBaa_acc_number(long baa_acc_number) {
		this.baa_acc_number = baa_acc_number;
	}
	public String getBaa_customer_name() {
		return baa_customer_name;
	}
	public void setBaa_customer_name(String baa_customer_name) {
		this.baa_customer_name = baa_customer_name;
	}
	public String getBaa_branch_name() {
		return baa_branch_name;
	}
	public void setBaa_branch_name(String baa_branch_name) {
		this.baa_branch_name = baa_branch_name;
	}
	public String getBaa_city() {
		return baa_city;
	}
	public void setBaa_city(String baa_city) {
		this.baa_city = baa_city;
	}
	public long getPin_code() {
		return pin_code;
	}
	public void setPin_code(long pin_code) {
		this.pin_code = pin_code;
	}
	public double getBaa_acc_balance() {
		return baa_acc_balance;
	}
	public void setBaa_acc_balance(double baa_acc_balance) {
		this.baa_acc_balance = baa_acc_balance;
	}
}
