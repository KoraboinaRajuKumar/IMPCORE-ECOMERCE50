package core_java_topics.polymorphism.finalKeyword;

public class FinalWithMethod {

	 final void method1() {
		System.out.println("this is FinalWithMethod class....");
	}
}
