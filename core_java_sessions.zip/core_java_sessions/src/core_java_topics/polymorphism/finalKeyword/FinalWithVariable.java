package core_java_topics.polymorphism.finalKeyword;

public class FinalWithVariable {

	long acc_number = 123456789l;
	String holder_name = "Mohammed Kamran";
	String branch_name = "Raichur Branch";
	double acc_balance = 20000.0d;
	
	
	public void changeAccNumber() {
		acc_number = 987654321;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
