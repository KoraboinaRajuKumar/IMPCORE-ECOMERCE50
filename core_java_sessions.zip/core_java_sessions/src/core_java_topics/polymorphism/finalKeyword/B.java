package core_java_topics.polymorphism.finalKeyword;

final class B {

}
