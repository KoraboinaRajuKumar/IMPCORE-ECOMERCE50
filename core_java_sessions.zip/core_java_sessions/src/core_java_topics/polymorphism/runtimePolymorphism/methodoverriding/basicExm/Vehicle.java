package core_java_topics.polymorphism.runtimePolymorphism.methodoverriding.basicExm;

public class Vehicle {

	public void start() {
		System.out.println("Vehicle is starting.....");
	}
	
	public void stop() {
		System.out.println("Vehicle is stopping.....");
	}
}
