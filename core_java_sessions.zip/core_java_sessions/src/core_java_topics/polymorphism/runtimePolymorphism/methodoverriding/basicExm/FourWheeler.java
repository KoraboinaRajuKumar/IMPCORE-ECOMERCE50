package core_java_topics.polymorphism.runtimePolymorphism.methodoverriding.basicExm;

public class FourWheeler extends Vehicle{

	public void start() {
		System.out.println("This is Four Wheeler start method....");
	}
	
	public void stop() {
		System.out.println("This is Four Wheeler stop method.....");
	}
}
