package core_java_topics.polymorphism.runtimePolymorphism.methodoverriding.realtimeExm;

public class CreditCards {

	public void getCCDetails() {
		System.out.println("This is Credit Card Class method()......");
	}
}
