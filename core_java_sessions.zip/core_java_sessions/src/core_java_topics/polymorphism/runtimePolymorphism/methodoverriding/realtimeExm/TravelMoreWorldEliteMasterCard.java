package core_java_topics.polymorphism.runtimePolymorphism.methodoverriding.realtimeExm;

public class TravelMoreWorldEliteMasterCard extends CreditCards{

	public void getCCDetails() {
		System.out.println("================ This is TravelMoreWorldEliteMasterCard Details =================");
		System.out.println("Credit Card Number : 123456789");
		System.out.println("Holder Name : Mohammed Kamran");
		System.out.println("Online Offer of $200");
		System.out.println("$100 Companion flight voucher");
		System.out.println("No Annual Fee");
		System.out.println("Earn 3 points on every $1 spent");
		System.out.println("Credit Card Limit : $5000");
	}
}
