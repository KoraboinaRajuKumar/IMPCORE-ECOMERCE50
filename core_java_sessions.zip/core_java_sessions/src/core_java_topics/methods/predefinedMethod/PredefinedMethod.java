package core_java_topics.methods.predefinedMethod;

public class PredefinedMethod {

	public static void main(String[] args) {
		String name = "Aravind";
		System.out.println("Length of the name : " + name.length());
		System.out.println("Maximum Number : " + Math.max(12, 45));
		System.out.println("Minimum Number : " + Math.min(32, 65));
	}
}
