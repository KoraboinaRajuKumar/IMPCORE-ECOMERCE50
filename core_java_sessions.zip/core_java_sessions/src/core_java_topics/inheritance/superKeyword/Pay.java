package core_java_topics.inheritance.superKeyword;

public class Pay {

	long payment_id = 123445786l;
	String remarks = "Paid for petrol";
	String mode_of_payment = "Phone pe";
	double bill_amount = 400.0d;
	int pin_num = 1234;
	
	public void method1() {
		System.out.println("This is Pay class method");
	}
}
