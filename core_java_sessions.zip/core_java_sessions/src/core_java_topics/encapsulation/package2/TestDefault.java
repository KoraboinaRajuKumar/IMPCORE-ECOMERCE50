package core_java_topics.encapsulation.package2;

import core_java_topics.encapsulation.package1.SafeBalanceCheckingAccount;

public class TestDefault extends SafeBalanceCheckingAccount{

	public static void main(String[] args) {
		TestDefault account = new TestDefault();
		//account.displaySBCAAccInfo();
	}

}
