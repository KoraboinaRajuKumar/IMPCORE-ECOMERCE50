package core_java_topics.encapsulation.package1;

public class TestProtected {

	public static void main(String[] args) {
		
		RetailCustomerCreditLimit limit = new RetailCustomerCreditLimit();
		limit.displayCCLimit();
	}

}
