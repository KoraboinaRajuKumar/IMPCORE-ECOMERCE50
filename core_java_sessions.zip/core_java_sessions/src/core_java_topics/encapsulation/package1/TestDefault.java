package core_java_topics.encapsulation.package1;

public class TestDefault {

	public static void main(String[] args) {
		
		SafeBalanceCheckingAccount account = new SafeBalanceCheckingAccount();
		account.displaySBCAAccInfo();

	}

}
