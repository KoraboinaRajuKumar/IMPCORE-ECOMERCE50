package core_java_topics.encapsulation.package1;

public class TestPrivate {

	public static void main(String[] args) {
		WholesaleGTRFAccount account = new WholesaleGTRFAccount();
		account.gtrfAccInfo();

	}

}
