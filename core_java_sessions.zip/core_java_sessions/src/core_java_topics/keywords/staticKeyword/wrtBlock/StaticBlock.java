package core_java_topics.keywords.staticKeyword.wrtBlock;

public class StaticBlock {
	
	public static void main(String[] args) {
		System.out.println("This is main method...");

	}
	static {
		System.out.println("This is static block");
	}

}
