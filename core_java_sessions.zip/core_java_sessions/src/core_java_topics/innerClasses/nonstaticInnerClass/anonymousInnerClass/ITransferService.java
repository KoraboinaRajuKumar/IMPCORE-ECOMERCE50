package core_java_topics.innerClasses.nonstaticInnerClass.anonymousInnerClass;

public interface ITransferService {

	public abstract void thirdPartyPayment();
	public abstract void impsTransfer();
}
