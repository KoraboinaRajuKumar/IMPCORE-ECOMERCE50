package core_java_topics.abstraction.interfaceInJava.interfaceExm1;

public class KotakMahindra implements BankBazar{

	@Override
	public double getHomeLoanROI(String bankName) {
		// TODO Auto-generated method stub
		return 8.0d;
	}

}
