package core_java_topics.abstraction.interfaceInJava.interfaceExm1;

public interface BankBazar {

	public abstract double getHomeLoanROI(String bankName);
	
}
