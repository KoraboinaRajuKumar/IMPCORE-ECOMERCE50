package core_java_topics.abstraction.interfaceInJava.multipleInheritance;

public interface IVisaCardPay {

	public void cardPay();
}
