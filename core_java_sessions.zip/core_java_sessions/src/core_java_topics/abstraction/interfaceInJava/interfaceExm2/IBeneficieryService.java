package core_java_topics.abstraction.interfaceInJava.interfaceExm2;

public interface IBeneficieryService extends IAccountService {

	public abstract void addBeneficiery();
	void deleteBeneficiery();
	abstract void updateBeneFiciery();
}
