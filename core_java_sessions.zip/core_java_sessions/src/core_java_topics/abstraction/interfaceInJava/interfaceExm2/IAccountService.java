package core_java_topics.abstraction.interfaceInJava.interfaceExm2;

public interface IAccountService {

	void getAccountDetails(long acc_num);
	public abstract void isAccountActive();
}
