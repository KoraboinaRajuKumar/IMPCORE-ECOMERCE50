package core_java_topics.abstraction.interfaceInJava.interfaceExm3;

public interface A {

	void method1();
	void method2();
	void method3();
	void method4();
}
