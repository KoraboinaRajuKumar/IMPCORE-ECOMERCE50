package core_java_topics.abstraction.interfaceInJava.interfaceExm3;

public abstract class B implements A {

	@Override
	public void method1() {
		System.out.println("This is method1()");
	}

	@Override
	public void method2() {
		System.out.println("This is method2()");
	}

	
	@Override
	public void method4() {
		System.out.println("This is method4()");
	}

}
