package core_java_topics.abstraction.interfaceInJava.test;

public interface B {

	void m();
}
