package core_java_topics.abstraction.abstractClassInJava.abstractExm1;

public class TVSScooter extends Bike {

	@Override
	public void run() {
		System.out.println("Top speed 120 kmph");
	}

}
