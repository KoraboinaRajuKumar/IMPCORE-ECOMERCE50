package core_java_topics.abstraction.abstractClassInJava.abstractExm1;

public class HondaActiva extends Bike{

	@Override
	public void run() {
		System.out.println("Top speed 140 kmph");
	}

}
