package core_java_topics.abstraction.abstractClassInJava.abstractExm3;

public abstract class ForexDematAccount {

	public ForexDematAccount() {
		System.out.println("this is cinstructor of abstract class.....");
	}
	
	public abstract void displayAccInfo();
	
	public void method() {
		System.out.println("This is non abstract method.....");
	}
}
