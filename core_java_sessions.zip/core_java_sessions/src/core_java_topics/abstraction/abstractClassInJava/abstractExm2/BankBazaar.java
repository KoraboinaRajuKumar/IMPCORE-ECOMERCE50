package core_java_topics.abstraction.abstractClassInJava.abstractExm2;

public abstract class BankBazaar {

	public abstract double rateOfInterest();
	public abstract String processingFee();
	
}
