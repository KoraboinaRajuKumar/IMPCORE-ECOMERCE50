package core_java_topics.abstraction.abstractClassInJava.abstractExm2;

public class KotakMahindraBank extends BankBazaar{

	@Override
	public double rateOfInterest() {
		// TODO Auto-generated method stub
		return 8.70d;
	}

	@Override
	public String processingFee() {
		// TODO Auto-generated method stub
		return "Salaried: 0.5% Plus taxes; Self-Employed/Commercial: 1.0% Plus taxes. ";
	}

}
