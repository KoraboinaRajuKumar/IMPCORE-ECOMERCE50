package core_java_topics.abstraction.abstractClassInJava.abstractExm2;

public class HDFCHomeLoan extends BankBazaar{

	@Override
	public double rateOfInterest() {
		// TODO Auto-generated method stub
		return 8.70d;
	}

	@Override
	public String processingFee() {
		// TODO Auto-generated method stub
		return "Up to 0.50% or Rs.3000 Plus taxes, whichever is higher.";
	}

}
