package core_java_topics.abstraction.abstractClassInJava.abstractExm2;

public class UnionBankOfIndia extends BankBazaar{

	@Override
	public double rateOfInterest() {
		// TODO Auto-generated method stub
		return 8.35d;
	}

	@Override
	public String processingFee() {
		// TODO Auto-generated method stub
		return "0.50% of the loan amount.";
	}

}
