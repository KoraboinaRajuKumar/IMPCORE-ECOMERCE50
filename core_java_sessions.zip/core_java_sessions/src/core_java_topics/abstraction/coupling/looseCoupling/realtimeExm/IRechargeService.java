package core_java_topics.abstraction.coupling.looseCoupling.realtimeExm;

public interface IRechargeService {

	public abstract void recharge();
}
