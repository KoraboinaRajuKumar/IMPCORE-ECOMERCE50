package core_java_topics.abstraction.coupling.looseCoupling.basicExm;

public class F implements Show{

	@Override
	public void display() {
		System.out.println("This is Class F method");
	}

}
