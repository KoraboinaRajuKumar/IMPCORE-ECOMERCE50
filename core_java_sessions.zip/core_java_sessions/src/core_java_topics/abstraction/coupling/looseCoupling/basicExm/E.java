package core_java_topics.abstraction.coupling.looseCoupling.basicExm;

public class E implements Show{

	public E() {}
	@Override
	public void display() {
		System.out.println("This is Class E method..");
	}

}
