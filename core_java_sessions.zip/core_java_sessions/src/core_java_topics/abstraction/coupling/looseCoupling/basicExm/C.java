package core_java_topics.abstraction.coupling.looseCoupling.basicExm;

public class C implements Show {

	public C() {}
	@Override
	public void display() {
		System.out.println("This is Class C method..");
	}

}
