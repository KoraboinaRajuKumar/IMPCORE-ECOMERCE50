package core_java_topics.abstraction.coupling.looseCoupling.basicExm;

public interface Show {

	public abstract void display();
}
