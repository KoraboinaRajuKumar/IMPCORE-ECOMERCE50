package core_java_topics.abstraction.coupling.tightCoupling.basicExm;

public class C {

	public C() {}
	public void display() {
		System.out.println("This is Class C method");
	}
}
