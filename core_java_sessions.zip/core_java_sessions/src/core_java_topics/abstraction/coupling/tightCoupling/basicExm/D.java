package core_java_topics.abstraction.coupling.tightCoupling.basicExm;

public class D {

	public D() {}
	public void display() {
		System.out.println("This is Class D method");
	}
}
