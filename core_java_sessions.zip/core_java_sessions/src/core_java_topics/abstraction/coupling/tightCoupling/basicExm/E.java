package core_java_topics.abstraction.coupling.tightCoupling.basicExm;

public class E {

	public E() {}
	public void display() {
		System.out.println("This is Class E method");
	}
}
