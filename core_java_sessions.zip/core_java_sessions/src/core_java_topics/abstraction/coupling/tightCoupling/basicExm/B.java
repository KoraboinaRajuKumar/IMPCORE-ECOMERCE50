package core_java_topics.abstraction.coupling.tightCoupling.basicExm;

public class B {

	public B() {}
	public void display() {
		System.out.println("This is Class B method");
	}
}
