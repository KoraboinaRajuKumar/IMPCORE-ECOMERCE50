package core_java_topics.abstraction.coupling.tightCoupling.basicExm;

public class TightCouplingExm {

	public static void main(String[] args) {
		
		A a = new A();
		a.display();

	}

}
