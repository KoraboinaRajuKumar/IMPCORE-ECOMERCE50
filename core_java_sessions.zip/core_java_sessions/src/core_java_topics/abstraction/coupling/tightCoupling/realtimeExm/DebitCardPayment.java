package core_java_topics.abstraction.coupling.tightCoupling.realtimeExm;

public class DebitCardPayment {

	public DebitCardPayment() {}
	
	public void debitCardPaymentMethod() {
		System.out.println("Debit Card Number : 98776587");
		System.out.println("Cvv Number : 555");
		System.out.println("Pin Number : 3425");
		System.out.println("Transfer Date : 12-05-2024");
		System.out.println("Amount Transfered : 45000.0");
	}
}
