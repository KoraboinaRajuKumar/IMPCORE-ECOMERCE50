package core_java_topics.abstraction.coupling.tightCoupling.realtimeExm;

public class PaymentManagerApp {

	public static void main(String[] args) {
		
		PaymentManager manager = new PaymentManager();
		manager.transferMoney();

	}

}
