package core_java_topics.abstraction.coupling.tightCoupling.realtimeExm;

public class PayPalTransfer {

	public PayPalTransfer() {}
	
	public void transferVIAPayPal() {
		System.out.println("Transfer Id : 3565674547");
		System.out.println("Transfer Date : 15-05-2024");
		System.out.println("Transfer Amount : 15000.0");
	}
}
