package core_java_topics.abstraction.coupling.tightCoupling.realtimeExm;

public class CreditCardPayment {

	public CreditCardPayment() {}
	
	public void ccPayment() {
		System.out.println("Credit Card Number : 9876456");
		System.out.println("Transfer Amount : 25000.0");
		System.out.println("Transfer Date : 20-05-2024");
	}
}
