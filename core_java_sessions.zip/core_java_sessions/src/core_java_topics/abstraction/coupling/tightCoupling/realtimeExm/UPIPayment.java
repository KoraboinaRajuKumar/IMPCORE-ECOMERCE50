package core_java_topics.abstraction.coupling.tightCoupling.realtimeExm;

public class UPIPayment {

	public UPIPayment() {}
	
	public void upiTransferMoney() {
		System.out.println("UPI ID : 46768567587");
		System.out.println("Transfer Date : 28-05-2024");
		System.out.println("Transfer Amount : 50000.0");
	}
}
