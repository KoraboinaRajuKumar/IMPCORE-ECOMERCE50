package designPatterns.creationalDesignPattern.prototypeDesignPattern;

public interface Prototype {

	public Prototype clone();
}
